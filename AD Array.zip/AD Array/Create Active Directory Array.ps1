﻿# fixed variables 
$users = Import-Csv -Path .\users.csv

function AddUser() {
    param ( $NewUserObject, $Manager )
    
    New-ADUser `
        -Path $NewUserObject.Path `
        -Name $NewUserObject.DisplayName `
        -SamAccountName $NewUserObject.SAM`
        -GivenName $NewUserObject.GivenName `
        -Surname $NewUserObject.Surname `
        -DisplayName $NewUserObject.DisplayName `
        -UserPrincipalName $NewUserObject.UPN `
        -MobilePhone $NewUserObject.TelephoneNumber `
        -City $NewUserObject.City `
        -Company $NewUserObject.Company `
        -Department $NewUserObject.Department `
        -Manager $Manager `
        -AccountPassword (ConvertTo-SecureString -String $NewUserObject.Password -AsPlainText -Force) `
        -Enabled $true `
        -ChangePasswordAtLogon $true 

        Add-ADGroupMember -Identity ("CN=" + $NewUserObject.Department + " Users," + $NewUserObject.Path) -Members ("CN=" + $NewUserObject.DisplayName + "," + $NewUserObject.Path)

}

################################################################################


# create main OU of each site
$sites = New-Object System.Collections.Generic.List[string]
$users | % {
    if($sites.Contains($_.City) -eq $false) {
        $sites.Add($_.City)
        New-ADOrganizationalUnit -Name $_.City -Path "DC=smartcore,DC=com" -Description ("The Users Of The Company Branch In $_.City") -City $_.City -ProtectedFromAccidentalDeletion $false
    }
}
# create ou for eash department in every site
foreach ($s in $sites) {
    $deparments = New-Object System.Collections.Generic.List[string]
    foreach($u in $users) {
        if (($u.City -eq $s) -and ($deparments.Contains($u.Department) -eq $false)) {
            $deparments.Add($u.Department)
        }
    }
    # create security group of users for each department
    $deparments | % {
        $path = "OU=" + $s + ",DC=smartcore,DC=com"
        New-ADOrganizationalUnit -Name $_ -Path $path -ProtectedFromAccidentalDeletion $false
        New-ADGroup -Path ("OU=" + $_ + "," + $path) -Name "$_ Users" -GroupScope Global
    }
}


# get and insert managers to AD
$managers = @{}
$users | % {
    if($_.IsManager -eq "V") {
        $managers.Add($_.Department, "CN=" + $_.DisplayName + "," + $_.Path)
        AddUser -NewUserObject $_ 
    }
}

# insert other users to AD
$users | % {
    if($_.IsManager -ne "V") { 
        AddUser -NewUserObject $_ -Manager $managers[$_.Department]
    }
}
